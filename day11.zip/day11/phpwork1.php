<?php
if(isset($_POST["submit"])){
    if(isset($_POST["no_1"])&&isset($_POST["no_2"])){
        $no_1=$_POST["no_1"];
        $no_2=$_POST["no_2"];
        $res=$no_1+$no_2;
    }
}
     
?>
<html>
    <head>
        <title>phpwork2</title>
    </head>
    <body>
        <form action="#" method="post">
        <span>Enter no.1</span>
        <input type="number" name="no_1"><br><br>
        <span>Enter no.2</span>
        <input type="number" name="no_2"><br><br>
        <button name="submit">submit</button><br><br>
        <span>answer</span>
        <input type="number" name="ans" value="<?php if(isset($res)) echo $res;?>">
    </form>
    </body>
</html>