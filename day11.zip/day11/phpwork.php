<?php
    echo "hello";
    $a=5;
    $b=10;
    $c=$a+$b;
    echo $c;
?>